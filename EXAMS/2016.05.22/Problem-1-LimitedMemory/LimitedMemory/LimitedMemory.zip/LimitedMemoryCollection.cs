﻿using System.Collections.Generic;
using System.Collections;
using System.Linq;

namespace LimitedMemory
{
    public class LimitedMemoryCollection<K, V> : ILimitedMemoryCollection<K, V>
    {
        private LinkedList<Pair<K, V>> priorityCollection;
        private Dictionary<K, LinkedListNode<Pair<K, V>>> collection;

        public LimitedMemoryCollection(int capacity)
        {
            this.Capacity = capacity;
            this.priorityCollection = new LinkedList<Pair<K, V>>();
            this.collection = new Dictionary<K, LinkedListNode<Pair<K, V>>>();
        }

        public int Capacity { get; private set; }

        public int Count => this.collection.Count;

        public void Set(K key, V value)
        {
            if (this.collection.ContainsKey(key))
            {
                var pair = this.collection[key];
                this.priorityCollection.Remove(pair);
                pair.Value.Value = value;
                this.priorityCollection.AddFirst(pair);
            }
            else
            {
                if (this.Count >= this.Capacity)
                {
                    var pairToRemove = this.priorityCollection.Last;
                    this.collection.Remove(pairToRemove.Value.Key);
                    this.priorityCollection.RemoveLast();
                }

                var newPair = new LinkedListNode<Pair<K, V>>(new Pair<K, V>(key, value));
                this.collection.Add(key, newPair);
                this.priorityCollection.AddFirst(newPair);
            }
        }

        public V Get(K key)
        {
            if (!this.collection.ContainsKey(key))
            {
                throw new KeyNotFoundException();
            }

            var pair = this.collection[key];
            this.priorityCollection.Remove(pair);
            this.priorityCollection.AddFirst(pair);
            return pair.Value.Value;
        }

        public IEnumerator<Pair<K, V>> GetEnumerator()
        {
            foreach (var kvp in this.priorityCollection)
            {
                yield return kvp;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}