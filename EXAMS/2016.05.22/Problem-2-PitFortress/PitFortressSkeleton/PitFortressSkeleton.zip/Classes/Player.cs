﻿using System;

namespace Classes
{
    using Interfaces;

    public class Player : IPlayer
    {
        private int radius;

        public Player(string name, int radius)
        {
            this.Name = name;
            this.Radius = radius;
        }

        public string Name { get; }

        public int Radius
        {
            get => this.radius;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }

                this.radius = value;
            }
        }

        public int Score { get; set; }

        public int CompareTo(Player other)
        {
            var compare = this.Score.CompareTo(other.Score);

            if (compare == 0)
            {
                compare = this.Name.CompareTo(other.Name);
            }
            return compare;
        }
    }
}